from flask import Flask, render_template, request
import gspread
from google.oauth2.service_account import Credentials

app = Flask(__name__)

# Google Sheets authentication
scopes = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive"
]

credentials = Credentials.from_service_account_file(
    "service_account.json",
    scopes=scopes
)

client = gspread.authorize(credentials)
sheet = client.open("FormData").sheet1

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        name = request.form["name"]
        age = request.form["age"]
        email = request.form["email"]

        sheet.append_row([name, age, email])

        return "Data saved successfully"

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)